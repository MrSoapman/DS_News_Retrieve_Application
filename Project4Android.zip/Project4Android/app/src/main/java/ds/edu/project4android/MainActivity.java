package ds.edu.project4android;

import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import ds.edu.project4android.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

/**
 * Author: Sennan Cen (sennanc)
 * Last Modified: Nov 19, 2023
 *
 * This class is the main activity of the Android application
 * It will display the UI and handle the user inputs
 * It will also call the NewsParseEngine to send the request to the server and parse the response
 * Then, it will update the UI with the parsed data
 */
public class MainActivity extends AppCompatActivity {

    private EditText editTextSearchInput, editTextDate;
    private Button buttonSubmit;
    private TextView textViewSubmitFeedback;
    private RecyclerView recyclerView;
    private NewsParseEngine newsParseEngine;

    MainActivity mainClass = this; // follow the similar implementation from InterestingPicture.java in our Android Lab so that our background task can successfully call back to this class

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.content_main);

        // initialize the UI elements
        editTextSearchInput = findViewById(R.id.editTextSearchInput);
        editTextDate = findViewById(R.id.editTextDate);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        textViewSubmitFeedback = findViewById(R.id.textViewSubmitFeedback);
        recyclerView = findViewById(R.id.recyclerView);

        // initialize the newsParseEngine
        newsParseEngine = new NewsParseEngine();

        final MainActivity mainClass2 = this; // follow the similar implementation from InterestingPicture.java in our Android Lab so that our background task can successfully call back to this class


        // add the listener to the button submit
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String searchKeyword = editTextSearchInput.getText().toString();
                String searchDate = editTextDate.getText().toString();

                boolean isGoodInputs = isGoodInputs(searchKeyword, searchDate);
                if (!isGoodInputs) {
                    textViewSubmitFeedback.setText("Bad inputs! Please try again!");
                    return;
                }

                // clear the feedback text view
                textViewSubmitFeedback.setText("");

                // will execute the search in background; when finish, call this class newsReady() method
                newsParseEngine.search(searchKeyword, searchDate, mainClass, mainClass2);
            }
        });
    }


    public boolean isGoodInputs(String searchName, String searchDate) {

        // I reused the code of checking from my Server files

        // check searchName and searchDate is not null or empty
        if (searchName == null || searchName.length() == 0) {
            return false;
        }

        if (searchDate == null || searchDate.length() == 0) {
            return false;
        }

        // cannot have '-' at the end
        if (searchName.charAt(searchName.length() - 1) == '-') {
            return false;
        }

        // check searchDate is in "year-month-day" format
        String[] dateParts = searchDate.split("-");
        if (dateParts.length != 3) {
            return false;
        } else if (dateParts[0].length() != 4) {
            return false;
        } else if (dateParts[1].length() != 2) {
            return false;
        } else if (dateParts[2].length() != 2) {
            return false;
        }

        try {
            int year = Integer.parseInt(dateParts[0]);
            int month = Integer.parseInt(dateParts[1]);
            int day = Integer.parseInt(dateParts[2]);

            if (year < 0 || month < 0 || day < 0) {
                return false;
            } else if (month > 12) {
                return false;
            } else if (day > 31) {
                return false;
            }

            // check searchDate is not in the future or one month away from now
            // The code below are referenced from the java doc: https://docs.oracle.com/javase/8/docs/api/java/time/LocalDate.html
            // and: https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/time/temporal/ChronoUnit.html#MONTHS

            LocalDate inputDate = LocalDate.of(year, month, day);
            LocalDate currentDate = LocalDate.now();
            if (inputDate.isAfter(currentDate)) {
                return false;
            }

            // check if the searchDate is not one month away from now -- not supported by API
            long monthsBetween = ChronoUnit.MONTHS.between(inputDate, currentDate);
            if (monthsBetween > 1) {
                return false;
            }

        } catch (NumberFormatException e) {
            return false;
        }

        return true;
    }

    public void newsReady(ArrayList<NewsArticle> newsArticlesArray) {
        // update the UI with the newsArticlesArray
        NewsArticleAdapter adapter = new NewsArticleAdapter(newsArticlesArray);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
}