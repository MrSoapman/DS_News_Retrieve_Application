package ds.edu.project4android;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * NewsArticleAdapter is the adapter for the RecyclerView in MainActivity
 * It is responsible for displaying the data at a specified position
 * in the RecyclerView.
 * <p>
 *     This class is implemented base on the guidance website: https://developer.android.com/reference/androidx/recyclerview/widget/RecyclerView.Adapter
 *     and stackoverflow: https://stackoverflow.com/questions/40584424/simple-android-recyclerview-example
 */
public class NewsArticleAdapter extends RecyclerView.Adapter<NewsArticleAdapter.NewsArticleViewHolder> {

    private ArrayList<NewsArticle> newsArticles;

    public NewsArticleAdapter(ArrayList<NewsArticle> newsArticles) {
        this.newsArticles = newsArticles;
    }

    public static class NewsArticleViewHolder extends RecyclerView.ViewHolder {
        public TextView title, author, url, description, publishedAt;

        public NewsArticleViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.textViewNewsTitle);
            author = itemView.findViewById(R.id.textViewNewsAuthor);
            url = itemView.findViewById(R.id.textViewNewsURL);
            description = itemView.findViewById(R.id.textViewNewsDescription);
            publishedAt = itemView.findViewById(R.id.textViewNewsPublishedAt);
        }
    }

    @Override
    public NewsArticleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_article_results, parent, false);
        return new NewsArticleViewHolder(v);
    }


    @Override
    public void onBindViewHolder(NewsArticleViewHolder holder, int position) {
        NewsArticle currentArticle = newsArticles.get(position);
        holder.title.setText(currentArticle.getTitle());
        holder.author.setText("From: " + currentArticle.getAuthor());
        holder.url.setText(currentArticle.getUrl());
        holder.description.setText(currentArticle.getDescription());
        holder.publishedAt.setText("Published At: " + currentArticle.getPublishedAt());
    }

    @Override
    public int getItemCount() {
        return newsArticles.size();
    }

}

