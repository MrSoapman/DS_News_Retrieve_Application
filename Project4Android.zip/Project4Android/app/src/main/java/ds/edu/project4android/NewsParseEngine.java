package ds.edu.project4android;

import android.app.Activity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

/**
 * Author: Sennan Cen (sennanc)
 * Last Modified: Nov 19, 2023
 *
 * This class is the engine to request and parse the news articles from the server
 * It will use the background thread to send the request to the server and receive the response
 * Then, it will use the main UI thread to update the UI
 */
public class NewsParseEngine {

    MainActivity mainActivity;
//    static final String serverURLHead = "http://10.0.2.2:8080/Project4ServletServer-1.0-SNAPSHOT/api/news/"; // for local testing
//    static final String serverURLHead = "http://10.0.2.2:8080/api/news/"; // for docker locally testing
//    static final String serverURLHead = "https://cuddly-zebra-95g7554gr46hxwj4-8080.app.github.dev/api/news/"; // for remote Codespaces testing with my own repo
    static final String serverURLHead = "https://musical-waddle-vrj6rr7jxv92xg4g-8080.app.github.dev/api/news/"; // for remote Codespaces testing with assigned repo

    String searchKeyword;

    String searchDate;

    JSONArray newsArticlesJSONArray;

    ArrayList<NewsArticle> newsArticlesArray;

    // using GSON to parse JSONArray sent by our server
    public void search(String searchKeyword, String searchDate, Activity activity, MainActivity mainActivity) {
        this.searchKeyword = searchKeyword;
        this.searchDate = searchDate;
        this.mainActivity = mainActivity;

        // let background thread to execute the sending and receiving of data from server
        new BackgroundTask(activity).startBackgroundTask();
    }

    private class BackgroundTask {

        // ### The implementation of this class is based on the BackgroundTask class in GetPicture.java in our "Lab 8 Android Application Lab" ###

        private Activity activity;

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        private void startBackgroundTask() {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    doInBackgroundDetail();

                    // use the main UI thread to update the UI since we have information from the server
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            onPostExecuteNewsReady();
                        }
                    });
                }
            }).start();
        }

        private void doInBackgroundDetail() {
            // send the searchKeyword and searchDate to the server and receive the JSONArray
            newsArticlesJSONArray = sendToServer(searchKeyword, searchDate);

            // convert the newsArticlesJSONArray to a NewsArticle object and check validity
            if (!transformAndCheckJSONArray(newsArticlesJSONArray)) {
                newsArticlesArray = new ArrayList<>();
                // add no news article found into the newsArticlesArray
                newsArticlesArray.add(new NewsArticle("No News Article Found", "", "", "", ""));
            }

        }

        public void onPostExecuteNewsReady() {
            mainActivity.newsReady(newsArticlesArray);
        }

        private JSONArray sendToServer(String searchKeyword, String searchDate) {

            // urlConnection to connect to the server
            HttpURLConnection urlConnection = null;
            // reader to read the response from the server
            BufferedReader reader = null;

            try {
                // construct the ULR for the query
                URL url = new URL(serverURLHead + searchKeyword + "/" + searchDate);

                // connect to the server
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // read the response from the server
                InputStreamReader inputStream = new InputStreamReader(urlConnection.getInputStream());
                reader = new BufferedReader(inputStream);
                StringBuilder builder = new StringBuilder();

                String oneLine;
                while ((oneLine = reader.readLine()) != null) {
                    builder.append(oneLine);
                }

                String serverResponse = builder.toString();

                return new JSONArray(serverResponse);
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (ProtocolException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }

        private boolean transformAndCheckJSONArray(JSONArray thisNewsJSONArray) {
            newsArticlesArray = new ArrayList<>();

            if (thisNewsJSONArray != null) {
                for (int i = 0; i < thisNewsJSONArray.length(); i++) {
                    try {
                        JSONObject articleJson = thisNewsJSONArray.getJSONObject(i);
                        NewsArticle oneArticle = new NewsArticle();

                        // enter each data into the NewsArticle object
                        oneArticle.setAuthor(articleJson.optString("author", "Unknown"));
                        oneArticle.setTitle(articleJson.optString("title", "No Title"));
                        oneArticle.setDescription(articleJson.optString("description", "No Description"));
                        oneArticle.setUrl(articleJson.optString("url", "No URL"));
                        oneArticle.setPublishedAt(articleJson.optString("publishedAt", "No Date"));

                        newsArticlesArray.add(oneArticle);

                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                }
                return true;
            } // else, will create an empty newsArticlesArray
            return false;
        }
    }

}
