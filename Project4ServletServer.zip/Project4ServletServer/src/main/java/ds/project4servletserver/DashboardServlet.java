package ds.project4servletserver;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    private static JSONArray logMobileToServer = new JSONArray();
    private static JSONArray logServerToAPI = new JSONArray();
    private static JSONArray logAPIToServer = new JSONArray();
    private static JSONArray logServerToMobile = new JSONArray();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Dashboard logic

        // prepare the data among Mobile, Server, and API
        prepareLogMobileToServer(request, response);
        prepareLogServerToAPI(request, response);
        prepareLogAPIToServer(request, response);
        prepareLogServerToMobile(request, response);

        // analyze the user input
        analyzeUserInput(request, response);

        // finally, forward to JSP
        request.getRequestDispatcher("dashboard_main.jsp")
                .forward(request, response);

    }

    private void prepareLogMobileToServer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the log of Mobile to Server from MongoDB
        logMobileToServer = MongoDBService.getLogMobileToServer();
        request.setAttribute("logMobileToServerJSONArray", logMobileToServer);
    }

    private void prepareLogServerToAPI(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the log of Server to API from MongoDB
        logServerToAPI = MongoDBService.getLogServerToAPI();
        request.setAttribute("logServerToAPIJSONArray", logServerToAPI);
    }

    private void prepareLogAPIToServer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the log of API to Server from MongoDB
        logAPIToServer = MongoDBService.getLogAPIToServer();
        request.setAttribute("logAPIToServerJSONArray", logAPIToServer);
    }

    private void prepareLogServerToMobile(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the log of Server to Mobile from MongoDB
        logServerToMobile = MongoDBService.getLogServerToMobile();
        request.setAttribute("logServerToMobileJSONArray", logServerToMobile);
    }

    private void analyzeUserInput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // count the number of times each keyword and date appears
        countUserInputKeywordAndDate(request, response);

        // find the earliest and latest date
        getEarliestAndLatestDate(request, response);
    }

    private void countUserInputKeywordAndDate(HttpServletRequest request, HttpServletResponse response) {
        // get a dict map of user input keyword & date to number of times it appears
        HashMap<String, Integer> keywordToCount = new HashMap<>();
        HashMap<String, Integer> dateToCount = new HashMap<>();
        for (int i = 0; i < logMobileToServer.length(); i++) {
            try {
                Object item = logMobileToServer.get(i);
                JSONObject jsonObj;
                if (item instanceof String) {
                    jsonObj = new JSONObject((String) item);
                } else if (item instanceof JSONObject) {
                    jsonObj = (JSONObject) item;
                } else {
                    continue;
                }
                String keyword = jsonObj.getString("searchName");
                if (keywordToCount.containsKey(keyword)) {
                    keywordToCount.put(keyword, keywordToCount.get(keyword) + 1);
                } else {
                    keywordToCount.put(keyword, 1);
                }

                String searchDate = jsonObj.getString("searchDate");
                if (dateToCount.containsKey(searchDate)) {
                    dateToCount.put(searchDate, dateToCount.get(searchDate) + 1);
                } else {
                    dateToCount.put(searchDate, 1);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // sort the dict map by value
        ArrayList<Map.Entry<String, Integer>> keywordToCountList = new ArrayList<>(keywordToCount.entrySet());
        keywordToCountList.sort(Map.Entry.comparingByValue());
        // put the top 5 frequent keywords to request attribute
        ArrayList<String> top5Keywords = new ArrayList<>();
        for (int i = 0; i < Math.min(5, keywordToCountList.size()); i++) {
            top5Keywords.add(keywordToCountList.get(i).getKey());
        }
        request.setAttribute("top5Keywords", top5Keywords);

        ArrayList<Map.Entry<String, Integer>> dateToCountList = new ArrayList<>(dateToCount.entrySet());
        dateToCountList.sort(Map.Entry.comparingByValue());
        // put the top 5 frequent dates to request attribute
        ArrayList<String> top5Dates = new ArrayList<>();
        for (int i = 0; i < Math.min(5, dateToCountList.size()); i++) {
            top5Dates.add(dateToCountList.get(i).getKey());
        }
        request.setAttribute("top5Dates", top5Dates);
    }

    private void getEarliestAndLatestDate(HttpServletRequest request, HttpServletResponse response) {
        // get the earliest and latest date using LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        LocalDate earliestDate = null;
        LocalDate latestDate = null;

        for (int i = 0; i < logMobileToServer.length(); i++) {
            try {
                Object item = logMobileToServer.get(i);
                JSONObject jsonObj;
                if (item instanceof String) {
                    jsonObj = new JSONObject((String) item);
                } else if (item instanceof JSONObject) {
                    jsonObj = (JSONObject) item;
                } else {
                    continue;
                }
                String searchDateStr = jsonObj.getString("searchDate");
                LocalDate searchDate = LocalDate.parse(searchDateStr, formatter);

                if (earliestDate == null || searchDate.isBefore(earliestDate)) {
                    earliestDate = searchDate;
                }
                if (latestDate == null || searchDate.isAfter(latestDate)) {
                    latestDate = searchDate;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // pass to request attribute
        if (earliestDate != null) {
            request.setAttribute("earliestDate", earliestDate.format(formatter));
        } else {
            request.setAttribute("earliestDate", "");
        }
        if (latestDate != null) {
            request.setAttribute("latestDate", latestDate.format(formatter));
        } else {
            request.setAttribute("latestDate", "");
        }
    }


}
