package ds.project4servletserver;


import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

public class GoogleNewsFetcher {

    // Record the API Key and the endpoint needed for the Google News API
    private static final String API_KEY = "b5f248004fd440c2957865a2760d587a";

    private static final int MAX_ARTICLES = 10;

    public static String mostRecentURL = "";

    public static JSONArray fetchArticles(String keyword, String fromDate, String toDate) throws Exception {
        // Build the URL for the API request
        String url_prefix = "https://newsapi.org/v2/everything";

        // The url of request came from the Google News API documentation: https://newsapi.org/docs/get-started#search
        // sample url: 'https://newsapi.org/v2/everything?'
        //       'q=Apple&'
        //       'from=2023-11-03&'
        //       'sortBy=popularity&'
        //       'apiKey=b5f248004fd440c2957865a2760d587a'
        String url = String.format("%s?q=%s&from=%s&to=%s&sortBy=publishedAt&apiKey=%s",
            url_prefix, URLEncoder.encode(keyword, StandardCharsets.UTF_8), fromDate, toDate, API_KEY);

        mostRecentURL = url;

        // Send the request and receive the response
        HttpClient client = HttpClient.newHttpClient();
        URI uri = URI.create(url);
        HttpRequest request = HttpRequest.newBuilder().uri(uri).build();

        // received response from the server
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        // If the response is not successful, throw an exception
        if (response.statusCode() != 200) {
            // Handle non-successful response
            throw new IOException("Error response from Google News API: " + response.body());
        }

        // Parse the response into a JSON object
        JSONObject jsonObject = new JSONObject(response.body());
        if (!jsonObject.has("articles")) {
            // If there's no "articles" JSON array, print the whole JSON response for debugging
            System.out.println("Check whether 'articles' in response JSON");
            return new JSONArray();
        }

        // Get the "articles" JSON array
        JSONArray articles = jsonObject.getJSONArray("articles");

        // Only return max 10 articles
        JSONArray top10Articles = new JSONArray();
        for (int i = 0; i < Math.min(MAX_ARTICLES, articles.length()); i++) {
            top10Articles.put(articles.getJSONObject(i));
        }

        return top10Articles;
    }
}







