package ds.project4servletserver;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import ds.project4servletserver.logs.LogAPIToServer;
import ds.project4servletserver.logs.LogMobileToServer;
import ds.project4servletserver.logs.LogServerToAPI;
import ds.project4servletserver.logs.LogServerToMobile;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;


public class MongoDBService {

    // The code below contains the connection to MongoDB Atlas
    // It is modified based on the connection full code sample provided by: https://cloud.mongodb.com/v2/6543f49a20d89d12716077c7#/clusters
    private static final String CONNECTION_STRING = "mongodb+srv://sennanc:shirleyzuimei@cluster-task1.ys1at0j.mongodb.net/?retryWrites=true&w=majority";

    // Name of the database within MongoDB Atlas free cluster
    private static final String DATABASE_NAME = "NewsDatabase";

    // Sub-collection name within the database - change it will create new sub-collection
    private static final String COLLECTION_NAME = "Articles";

    // sub-collection name for logs
    private static final String LOG_MOBILE_TO_SERVER_COLLECTION_NAME = "LogMobileToServer";
    private static final String LOG_SERVER_TO_MOBILE_COLLECTION_NAME = "LogServerToMobile";
    private static final String LOG_SERVER_TO_API_COLLECTION_NAME = "LogServerToAPI";
    private static final String LOG_API_TO_SERVER_COLLECTION_NAME = "LogAPIToServer";

    private static final int MAX_ARTICLES = 10;

    /**
     * Store the API received articles to MongoDB
     * For Project 4 Task 1, this method is not used
     * @param articles
     * @param keyword
     */
    public static void saveArticles(JSONArray articles, String keyword) {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);

        // only store the top 10 articles
        if (articles.length() > MAX_ARTICLES) {
            articles = new JSONArray(articles.toList().subList(0, MAX_ARTICLES));
        }

        articles.forEach(item -> {
            JSONObject article = (JSONObject) item;
            Document doc = new Document()
                    .append("keyword", keyword) // keyword is the parameter passed in from the user input
                    .append("title", article.getString("title"))
                    .append("date", article.getString("publishedAt"))
                    .append("url", article.getString("url"))
                    .append("content", article.getString("content"));

            // print out to the console that we are storing
            System.out.println("Storing article: " + article.getString("title")
                    + ", with keyword: " + keyword + " to MongoDB");
            collection.insertOne(doc);
        });
        System.out.println("Finished storing all the articles to MongoDB ==================================");
        mongoClient.close();
    }

    /**
     * Read all the articles from MongoDB
     * For Project 4 Task 1, this method is not used
     */
    public static void readArticles() {
        // Connect to MongoDB Atlas
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        // Read all the documents currently stored in the collection
        MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);

        // print out to the console that we are reading
        System.out.println("Reading all the articles from MongoDB");
        collection.find().forEach(document -> System.out.println(document.toJson()));

        mongoClient.close();
    }

    /**
     * Clean the database
     */
    public static void cleanDatabase() {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);

        // Delete all documents from the collection
        collection.deleteMany(new Document());

        mongoClient.close();
    }

    /**
     * Store the log from mobile to server
     * @param log
     */
    public static void insertLogMobileToServer(LogMobileToServer log) {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(LOG_MOBILE_TO_SERVER_COLLECTION_NAME);

        Document doc = new Document()
                .append("searchName", log.getSearchName())
                .append("searchDate", log.getSearchDate())
                .append("convertedSearchStartDate", log.getConvertedSearchStartDate())
                .append("convertedSearchEndDate", log.getConvertedSearchEndDate());

        collection.insertOne(doc);
        mongoClient.close();
    }

    /**
     * Get the log from mobile to server from MongoDB
     */
    public static JSONArray getLogMobileToServer() {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(LOG_MOBILE_TO_SERVER_COLLECTION_NAME);

        // get the entire document and convert to a JSON array
        JSONArray jsonArray = new JSONArray();
        collection.find().forEach(document -> jsonArray.put(document.toJson()));

        mongoClient.close();

        return jsonArray;
    }

    /**
     * Store the log from server to mobile
     * @param log
     */
    public static void insertLogServerToMobile(LogServerToMobile log) {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(LOG_SERVER_TO_MOBILE_COLLECTION_NAME);

        Document doc = new Document()
                .append("newsArrayToSend", log.getNewsArrayToSend().toString());

        collection.insertOne(doc);
        mongoClient.close();
    }

    /**
     * Get the log from server to mobile from MongoDB
     */
    public static JSONArray getLogServerToMobile() {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(LOG_SERVER_TO_MOBILE_COLLECTION_NAME);


//        collection.find().forEach(document -> System.out.println(document.toJson()));
        // get the entire document and convert to a JSON array
        JSONArray jsonArray = new JSONArray();
        collection.find().forEach(document -> jsonArray.put(document.toJson()));
        mongoClient.close();

        return jsonArray;
    }

    /**
     * Store the log from server to API
     * @param log
     */
    public static void insertLogServerToAPI(LogServerToAPI log) {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(LOG_SERVER_TO_API_COLLECTION_NAME);

        Document doc = new Document()
                .append("searchName", log.getSearchName())
                .append("searchStartDate", log.getSearchStartDate())
                .append("searchEndDate", log.getSearchEndDate())
                .append("searchURL", log.getSearchURL());

        collection.insertOne(doc);
        mongoClient.close();
    }

    /**
     * Get the log from server to API from MongoDB
     */
    public static JSONArray getLogServerToAPI() {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(LOG_SERVER_TO_API_COLLECTION_NAME);

        // get the entire document and convert to a JSON array
        JSONArray jsonArray = new JSONArray();
        collection.find().forEach(document -> jsonArray.put(document.toJson()));

        mongoClient.close();
        return jsonArray;
    }

    /**
     * Store the log from API to server
     * @param log
     */
    public static void insertLogAPIToServer(LogAPIToServer log) {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(LOG_API_TO_SERVER_COLLECTION_NAME);

        Document doc = new Document()
                .append("newsArrayReceived", log.getNewsArray().toString())
                .append("responseTime", log.getResponseTime())
                .append("isSuccessful", log.getIsSuccessful());

        collection.insertOne(doc);
        mongoClient.close();
    }

    /**
     * Get the log from API to server from MongoDB
     */
    public static JSONArray getLogAPIToServer() {
        MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(LOG_API_TO_SERVER_COLLECTION_NAME);

        // get the entire document and convert to a JSON array
        JSONArray jsonArray = new JSONArray();
        collection.find().forEach(document -> jsonArray.put(document.toJson()));
        mongoClient.close();

        return jsonArray;
    }


}
