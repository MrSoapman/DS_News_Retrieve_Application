package ds.project4servletserver;

import ds.project4servletserver.logs.LogAPIToServer;
import ds.project4servletserver.logs.LogMobileToServer;
import ds.project4servletserver.logs.LogServerToAPI;
import ds.project4servletserver.logs.LogServerToMobile;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
//import jakarta.ws.rs.Path;
import org.json.JSONArray;
import org.json.JSONObject;

//import javax.servlet.*;
//import javax.servlet.http.*;
import java.io.IOException;
import com.google.gson.Gson;

@WebServlet(name = "NewsServlet", urlPatterns = {"/api/news/*"})
public class NewsServlet extends HttpServlet {

    GoogleNewsFetcher gnf = new GoogleNewsFetcher();

    @Override
    public void init() {
        gnf = new GoogleNewsFetcher();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Get the path info from the request
        String pathInfo = request.getPathInfo();

        // Assuming the path is something like "/searchName/searchDate"
        if (pathInfo != null) {
            String[] pathParts = pathInfo.split("/");

            if (pathParts.length >= 3) {
                // Start from Index 1 because 0 is an empty string before the first '/'
                String searchName = pathParts[1];
                String searchDate = pathParts[2];

                response.setContentType("text/plain");

                // check if searchName and searchDate are valid
                if (!isInputValid(searchName, searchDate)) {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST,
                            "Invalid request: check your search name and date");
                    return;
                }

                // Change from searchDate to a range: searchDate - 1 to searchDate
                String[] dateRange = new String[2];
                dateRange = executeDateRange(searchDate);
                String previousDate = dateRange[0];
                String afterDate = dateRange[1];

                // This is the end of fetching data from mobile app-------------------

                // store the log of the mobile app to the server
                StoreLogMobileToServer(searchName, searchDate, previousDate, afterDate);

                // fetch news from Google News API and record the time
                JSONArray news = null;
                long startTime = System.currentTimeMillis();
                try {
                    news = gnf.fetchArticles(searchName, previousDate, afterDate);
                } catch (Exception e) {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST,
                            "API has error on fetching articles");
                }
                long endTime = System.currentTimeMillis();

                // Store the log of server request to API
                StoreLogServerToAPI(searchName, previousDate, afterDate, GoogleNewsFetcher.mostRecentURL);

                // if json array is empty JSONArray object, then there is no news found
                if (news == null || news.isEmpty()) {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST,
                            "API: No news found");

                    // Store the log of API response to server with failed status
                    StoreLogAPIToServer(news, endTime - startTime, false);

                } else {
                    // write back to the client as response with specific useful information
                    JSONArray filteredNews = filterNews(news);

                    // Store the log of API response to server
                    StoreLogAPIToServer(news, endTime - startTime, true);

                    // Store the log of Server response to mobile app
                    StoreLogServerToMobile(filteredNews);

                    response.getWriter().write(filteredNews.toString());
                }

            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid request");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid request");
        }
    }

    private JSONArray filterNews(JSONArray news) {
        // filtering the news
        JSONArray filteredNews = new JSONArray();

        // for each article, only keep the author, title, description, url, and publishedAt
        for (int i = 0; i < news.length(); i++) {
            JSONObject article = news.getJSONObject(i);
            JSONObject filteredArticle = new JSONObject();

            filteredArticle.put("author", article.optString("author"));
            filteredArticle.put("title", article.optString("title"));
            filteredArticle.put("description", article.optString("description"));
            filteredArticle.put("url", article.optString("url"));
            filteredArticle.put("publishedAt", article.optString("publishedAt"));

            filteredNews.put(filteredArticle);
        }
        return filteredNews;
    }

    private boolean isInputValid(String searchName, String searchDate) {
        // check searchName and searchDate is not null or empty
        if (searchName == null || searchName.length() == 0) {
            return false;
        }

        if (searchDate == null || searchDate.length() == 0) {
            return false;
        }

        // check searchDate is in "year-month-day" format
        String[] dateParts = searchDate.split("-");
        if (dateParts.length != 3) {
            return false;
        } else if (dateParts[0].length() != 4) {
            return false;
        } else if (dateParts[1].length() != 2) {
            return false;
        } else if (dateParts[2].length() != 2) {
            return false;
        }

        try {
            int year = Integer.parseInt(dateParts[0]);
            int month = Integer.parseInt(dateParts[1]);
            int day = Integer.parseInt(dateParts[2]);
        } catch (NumberFormatException e) {
            return false;
        }

        return true;
    }

    private String[] executeDateRange(String searchDate) {
        // Change from searchDate to a range: searchDate - 1 to searchDate
        String[] dateRange = new String[2];

        // find the previous date
        String[] dateParts = searchDate.split("-");
        int year = Integer.parseInt(dateParts[0]);
        int month = Integer.parseInt(dateParts[1]);
        int day = Integer.parseInt(dateParts[2]);
        if (day == 1) {
            if (month == 1) {
                year--;
                month = 12;
                day = 31;
            } else {
                month--;
                day = 30; // for simplicity, assume every month has 30 days
            }
        } else {
            day--;
        }

        // convert back to string
        String yearStr = Integer.toString(year);
        String monthStr = Integer.toString(month);
        String dayStr = Integer.toString(day);
        if (monthStr.length() == 1) {
            monthStr = "0" + monthStr;
        }
        if (dayStr.length() == 1) {
            dayStr = "0" + dayStr;
        }

        String previousDate = yearStr + "-" + monthStr + "-" + dayStr;

        dateRange[0] = previousDate;
        dateRange[1] = searchDate;

        return dateRange;
    }

    private void StoreLogMobileToServer(String searchName, String searchDate, String convertedPreviousDate, String convertedAfterDate) {
        // store the log of the mobile app to the server
        LogMobileToServer logMobileToServer = new LogMobileToServer();
        logMobileToServer.setSearchName(searchName);
        logMobileToServer.setSearchDate(searchDate);
        logMobileToServer.setConvertedSearchStartDate(convertedPreviousDate);
        logMobileToServer.setConvertedSearchEndDate(convertedAfterDate);

        // store to MongoDB
        MongoDBService.insertLogMobileToServer(logMobileToServer);
    }

    private void StoreLogServerToAPI(String searchName, String previousDate, String afterDate, String mostRecentURL) {
        // store the log of the server request to API
        LogServerToAPI logServerToAPI = new LogServerToAPI();
        logServerToAPI.setSearchName(searchName);
        logServerToAPI.setSearchStartDate(previousDate);
        logServerToAPI.setSearchEndDate(afterDate);
        logServerToAPI.setSearchURL(mostRecentURL);

        // store to MongoDB
        MongoDBService.insertLogServerToAPI(logServerToAPI);
    }

    private void StoreLogAPIToServer(JSONArray news, long responseTime, boolean isSuccessful) {
        // store the log of the API response to the server
        LogAPIToServer logAPIToServer = new LogAPIToServer();
        logAPIToServer.setNewsArray(news);
        logAPIToServer.setResponseTime(responseTime);
        logAPIToServer.setIsSuccessful(isSuccessful);

        // store to MongoDB
        MongoDBService.insertLogAPIToServer(logAPIToServer);
    }

    private void StoreLogServerToMobile(JSONArray filteredNews) {
        // store the log of the server response to the mobile app
        LogServerToMobile logServerToMobile = new LogServerToMobile();
        logServerToMobile.setNewsArrayToSend(filteredNews);

        // store to MongoDB
        MongoDBService.insertLogServerToMobile(logServerToMobile);
    }

}
