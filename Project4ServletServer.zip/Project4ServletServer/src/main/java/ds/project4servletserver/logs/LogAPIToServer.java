package ds.project4servletserver.logs;

import org.json.JSONArray;

/**
 * Store the log of the API to the server.
 */
public class LogAPIToServer {
    private JSONArray newsArray;

    private long responseTime;

    private boolean isSuccessful;

    public JSONArray getNewsArray() {
        return newsArray;
    }

    public void setNewsArray(JSONArray newsArray) {
        this.newsArray = newsArray;
    }

    public long getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(long responseTime) {
        this.responseTime = responseTime;
    }

    public boolean getIsSuccessful() {
        return isSuccessful;
    }

    public void setIsSuccessful(boolean isSuccessful) {
        this.isSuccessful = isSuccessful;
    }
}
