package ds.project4servletserver.logs;

/**
 * Store the log of the mobile app to the server.
 */
public class LogMobileToServer {
    private String searchName;

    private String searchDate;

    private String convertedSearchStartDate;

    private String convertedSearchEndDate;

    public String getSearchName() {
        return searchName;
    }

    public void setSearchName(String searchName) {
        this.searchName = searchName;
    }

    public String getSearchDate() {
        return searchDate;
    }

    public void setSearchDate(String searchDate) {
        this.searchDate = searchDate;
    }

    public String getConvertedSearchStartDate() {
        return convertedSearchStartDate;
    }

    public void setConvertedSearchStartDate(String convertedSearchStartDate) {
        this.convertedSearchStartDate = convertedSearchStartDate;
    }

    public String getConvertedSearchEndDate() {
        return convertedSearchEndDate;
    }

    public void setConvertedSearchEndDate(String convertedSearchEndDate) {
        this.convertedSearchEndDate = convertedSearchEndDate;
    }
}
