package ds.project4servletserver.logs;

import org.json.JSONArray;

/**
 * Store the log of the server to the mobile app.
 */
public class LogServerToMobile {
    private JSONArray newsArrayToSend;

    public JSONArray getNewsArrayToSend() {
        return newsArrayToSend;
    }

    public void setNewsArrayToSend(JSONArray newsArrayToSend) {
        this.newsArrayToSend = newsArrayToSend;
    }
}
